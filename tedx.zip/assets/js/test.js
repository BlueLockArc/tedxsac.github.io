function showhide(show,hide) {
            document.getElementById(show).classList.remove("toggleable");
            document.getElementById(hide).classList.add("toggleable");
        }
